import pyesytime
print("PyEasyCom in version 2022.1")
print(pyesytime.ALL_IN_ONE())